const sql = require('mssql');
module.exports = function()
{
    const sqlConfig =
    {
        user: 'BD2221022',
        password: 'Batata123',
        database: 'BD',
        server: 'Apolo',
        options:
        {
            encrypt: false,
            trustServerCertificate: true
        }
    }
    return sql.connect(sqlConfig);
}