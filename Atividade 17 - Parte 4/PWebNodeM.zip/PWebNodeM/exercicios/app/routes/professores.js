module.exports = function(app)
{
    app.get('/informacao/professores', function(req, res)
    {
        async function getProfessores()
        {
            try
            {
                //const pool = await dbConnection();
                var connection = app.config.dbConnection;
                const pool = await connection();
                const results = await pool.request().query('SELECT * FROM Professores');
                res.render('informacao/professores', {profs: results.recordset});
                // res.send(results.recordsets);
            }
            catch (err)
            {
                console.log(err);
                res.status(500).send("Erro ao buscar os professores");
            }
           
        }
        getProfessores();
    });
}